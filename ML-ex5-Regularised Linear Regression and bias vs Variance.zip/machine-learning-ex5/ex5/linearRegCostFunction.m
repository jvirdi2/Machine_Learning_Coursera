function [J, grad] = linearRegCostFunction(X, y, theta, lambda)
%LINEARREGCOSTFUNCTION Compute cost and gradient for regularized linear 
%regression with multiple variables
%   [J, grad] = LINEARREGCOSTFUNCTION(X, y, theta, lambda) computes the 
%   cost of using theta as the parameter for linear regression to fit the 
%   data points in X and y. Returns the cost in J and the gradient in grad

% Initialize some useful values
m = length(y); % number of training examples

% You need to return the following variables correctly 
J = 0;
length_theta=size(theta);
grad = zeros(length_theta(1),1);

% ====================== YOUR CODE HERE ======================
% Instructions: Compute the cost and gradient of regularized linear 
%               regression for a particular choice of theta.
%
%               You should set J to the cost and grad to the gradient.
%
theta_x_value=X*theta;
difference=theta_x_value-y;
J_part_1=(1/(2*m))*sum(difference.*difference);
J_part_2=(lambda/(2*m))*(sum(theta(2:end).*theta(2:end)));
J=J_part_1+J_part_2;


for i=1:length_theta(1)
    matrix=(transpose(X)*difference);
    grad(i)=(1/m)*matrix(i);   % Intermediate value
end


grad=grad+((lambda/m)*(theta));
grad(1)=grad(1)-(lambda/m)*(theta(1));


%=========================================================================

grad=grad(:);
end


